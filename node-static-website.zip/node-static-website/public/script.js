document.getElementById("btn").addEventListener("click", function() {
  alert("Hello from Node.js Static Website!");
});
